package poly.com.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBContext {
    
    // Thông tin kết nối SQL Server
    private static final String SERVER = "localhost";
    private static final String PORT = "1433";
    private static final String DB_NAME = "ABCNewsDB"; // Tên Database bạn sẽ tạo
    private static final String USER = "sa";
    private static final String PASSWORD = "1234"; // <--- SỬA MẬT KHẨU SQL CỦA BẠN Ở ĐÂY

    public static Connection getConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://" + SERVER + ":" + PORT + ";databaseName=" + DB_NAME + ";encrypt=true;trustServerCertificate=true";
            return DriverManager.getConnection(url, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    // Chạy thử file này (Run as Java Application) để xem kết nối được chưa
    public static void main(String[] args) {
        System.out.println(getConnection() != null ? "Kết nối thành công!" : "Kết nối thất bại!");
    }
}