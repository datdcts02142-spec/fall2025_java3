package poly.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.com.config.DBContext;
import poly.com.entity.News;

public class NewsDAO {

    // 1. Hàm lấy Top 3 tin mới nhất (Dùng cho HomeServlet)
    public List<News> getTop3News() {
        List<News> list = new ArrayList<>();
        String sql = "SELECT TOP 3 * FROM NEWS ORDER BY PostedDate DESC";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                News n = new News();
                n.setId(rs.getString("Id"));
                n.setTitle(rs.getString("Title"));
                n.setContent(rs.getString("Content"));
                n.setImage(rs.getString("Image"));
                n.setPostedDate(rs.getDate("PostedDate"));
                n.setAuthorId(rs.getString("Author"));
                n.setViewCount(rs.getInt("ViewCount"));
                n.setCategoryId(rs.getString("CategoryId"));
                n.setHome(rs.getBoolean("Home"));
                
                list.add(n);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 2. Hàm lấy tin theo Danh mục (Dùng cho CategoryServlet) -> BẠN ĐANG THIẾU HÀM NÀY
    public List<News> getNewsByCategory(String categoryId) {
        List<News> list = new ArrayList<>();
        // Lệnh SQL: Lấy tin có CategoryId bằng tham số truyền vào
        String sql = "SELECT * FROM NEWS WHERE CategoryId = ? ORDER BY PostedDate DESC";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, categoryId); // Truyền mã loại (VD: 'TG', 'KD') vào dấu ?
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                News n = new News();
                n.setId(rs.getString("Id"));
                n.setTitle(rs.getString("Title"));
                n.setContent(rs.getString("Content"));
                n.setImage(rs.getString("Image"));
                n.setPostedDate(rs.getDate("PostedDate"));
                n.setAuthorId(rs.getString("Author"));
                n.setViewCount(rs.getInt("ViewCount"));
                n.setCategoryId(rs.getString("CategoryId"));
                n.setHome(rs.getBoolean("Home"));
                
                list.add(n);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}