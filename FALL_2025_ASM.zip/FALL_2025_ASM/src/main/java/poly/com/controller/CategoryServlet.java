package poly.com.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Đường dẫn này chạy khi bấm vào menu (link có dạng /news)
@WebServlet("/news") 
public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		// 1. Lấy mã loại tin từ đường dẫn (ví dụ ?id=XH)
		String id = request.getParameter("id");
		
		// 2. Kiểm tra ID để tạo tiêu đề cho đẹp (Giả lập dữ liệu)
		String categoryName = "Tin tức tổng hợp";
		
		if("XH".equals(id)) {
			categoryName = "Xã hội";
		} else if("TG".equals(id)) {
			categoryName = "Thế giới";
		} else if("KD".equals(id)) {
			categoryName = "Kinh doanh";
		} else if("TT".equals(id)) {
			categoryName = "Thể thao";
		}
		
		// 3. Gửi tên loại tin sang bên giao diện để hiển thị
		request.setAttribute("catName", categoryName);

		// 4. Chuyển hướng sang trang danh sách tin (list.jsp)
		request.getRequestDispatcher("/views/user/list.jsp").forward(request, response);
	}
}