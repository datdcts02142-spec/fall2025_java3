package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

// Đường dẫn này sẽ hứng khi người dùng bấm vào Logo hoặc nút Trang chủ
@WebServlet({"/home", "/index"}) 
public class HomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Sau này code lấy tin mới nhất từ DB sẽ viết ở đây
        
        // Chuyển hướng sang giao diện trang chủ
        request.getRequestDispatcher("/views/user/home.jsp").forward(request, response);
    }
}